#include "xml.h"

int main()
{
    Queue Q;
    createQueue(Q);
    inputxml(Q);

    cout << "========================================" << endl << endl;

    cout << "Tugas Besar Struktur Data XML Compiler" << endl;
    cout << "Kahfi Rizky Firmansyah 1301210233" << endl;
    cout << "Kartina Halawa 1301210245" << endl;
    cout << "IF-45-11" << endl << endl;

    cout << "========================================" << endl << endl;

    cout << "XML yang akan diperiksa: " << endl;
    ShowIsiQueue(Q);

    Stack S;
    createStack(S);
    bool valid;

    valid = cekValid(Q, S);

    if(valid){
        cout << "XML VALID" << endl;
        printStackFlipped(S);
    } else {
        cout << "XML TIDAK VALID" << endl;
    }

    cout << "========================================" << endl << endl;

    return 0;
}

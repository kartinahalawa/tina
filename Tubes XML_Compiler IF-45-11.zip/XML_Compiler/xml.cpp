#include "xml.h"

void createQueue(Queue &Q){
    head(Q) = nil;
    tail(Q) = nil;
}

void createElmQueue(char xml[xmlMax], adr &P){
    P = new elmQueue;
    for(int i = 0; i < xmlMax;i++){
        info(P)[i] = xml[i];
    }
    next(P) = nil;
}

bool isQueueEmpty(Queue Q){
    return (head(Q) == nil && tail(Q) == nil);
}

void enqueue(Queue &Q, adr P){
    if(isQueueEmpty(Q)){
        head(Q) = P;
        tail(Q) = P;
    } else {
        next(tail(Q)) = P;
        tail(Q) = P;
    }
}

void dequeue(Queue &Q, adr &P){
    if(isQueueEmpty(Q)){
        cout << "Queue Kosong" << endl;
    } else {
        if(head(Q) == tail(Q)){
            P = head(Q);
            next(P) = nil;
            head(Q) = nil;
            tail(Q) = nil;
        } else {
            P = head(Q);
            head(Q) = next(P);
            next(P) = nil;
        }
    }
}

void ShowIsiQueue(Queue Q){
    adr P = head(Q);
    while (P != nil){
        for (int i = 0; i < xmlMax; i++){
            cout << info(P)[i] << " ";
        }
        cout << endl;
        P = next(P);
    }
    cout << endl;
}

void createStack(Stack &S){
    S.top = 0;
}

bool isStackEmpty(Stack S){
    return (S.top == 0);
}

bool isStackFull(Stack S){
    return (S.top == stackMax);
}

void push(Stack &S, char xml[xmlMax]){
    if(!isStackFull(S)){
        S.top++;
        for(int i = 0; i < xmlMax; i++){
            S.info[S.top][i] = xml[i];
        }
    }
}

array<char, xmlMax> pop(Stack &S){
    array<char, xmlMax> xml;
    for(int i = 0; i < xmlMax; i++){
        xml[i] = S.info[S.top][i];
    }
    S.top--;
    return xml;
}

void printIsiStack(Stack S){
    for(int i = S.top; i >= 1 ; i--){
        for(int j = 0; j < xmlMax; j++){
            cout << S.info[i][j] << " ";
        }
        cout << endl;
    }
}
//==========tubes==========
bool cekTandaKurung(char xml[xmlMax]){
    int i = 0;
    while (xml[i+1] != nil){
        i++;
    }
    return (xml[0] == '<' && xml[i] == '>');
}

bool cekPenutup(char xml[xmlMax]){
    return (xml[1] == '/');
}

bool cekValid(Queue &Q, Stack &S){
    Stack Svalid;
    createStack(Svalid);

    array<char,xmlMax> cekxml;

    adr P;

    while (!isQueueEmpty(Q)){
        dequeue(Q, P);
        push(S, info(P));
        if (!cekTandaKurung(info(P))){
            return false;
        } else {
            if(!cekPenutup(info(P))){
                push(Svalid, info(P));
            } else {
                cekxml = pop(Svalid);
                if (cekxml[1] != info(P)[2]){
                    return false;
                }
            }
        }
    }
    return true;
}

void inputxml(Queue &Q){

    char input = ' ';
    int i = 0;
    adr P;
    while (input != '-' && i < stackMax-1){
        char xml[xmlMax];
        cout << "Masukan xml: ";
        cin >> input;
        int j = 0;
        if (input != '-'){
            while (input != '.' && input != '-' && j < xmlMax){
                xml[j] = input;
                j++;
                cin >> input;
            }
        createElmQueue(xml, P);
        enqueue(Q, P);
        }
        i++;
    }
    cout << endl;
}

void printStackFlipped(Stack &S){
    for(int i = 1; i < S.top+1; i++){
        for(int j = 0; j < xmlMax; j++){
            cout << S.info[i][j] << " ";
        }
        cout << endl;
    }
}

#ifndef XML_H_INCLUDED
#define XML_H_INCLUDED

#include <array>
#include <iostream>
using namespace std;

#define info(P) (P)->info
#define next(P) (P)->next
#define head(Q) ((Q).head)
#define tail(Q) ((Q).tail)
#define nil NULL

const int xmlMax = 5;
const int stackMax = 20;

typedef struct elmQueue *adr;
struct elmQueue{
    char info[xmlMax];
    adr next;
};

struct Queue{
    adr head, tail;
};

struct Stack{
    char info[stackMax][xmlMax];
    int top;
};

void createQueue(Queue &Q);
void createElmQueue(char xml[xmlMax], adr &P);
bool isQueueEmpty(Queue Q);
void enqueue(Queue &Q, adr P);
void dequeue(Queue &Q, adr &P);
void ShowIsiQueue(Queue Q);

void createStack(Stack &S);
bool isStackEmpty(Stack S);
bool isStackFull(Stack S);
void push(Stack &S, char xml[xmlMax]);
array<char, xmlMax> pop(Stack &S);
void printIsiStack(Stack S);

bool cekTandaKurung(char xml[xmlMax]);
bool cekPenutup(char xml[xmlMax]);
bool cekValid(Queue &Q, Stack &S);

void inputxml(Queue &Q);
void printStackFlipped(Stack &S);

#endif // XML_H_INCLUDED
